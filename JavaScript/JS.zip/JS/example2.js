function add(a, b) {
    return a + b;
}

console.log(add(2, 3));

const add2 = (a, b) => {
    return a + b;
}

console.log(add2(3, 3));

const add3 = (a, b) => a + b;

console.log(add3(4, 3));

function AddOne(a) {
    return a + 1;
}

console.log(AddOne(2));

const AddOne2 = a => a + 1;

console.log(AddOne2(3));

function Show5Square() {
    return 5 * 5;
}

console.log(Show5Square());

const Show5Square2 = () => 5 * 5;

const car = {
    make: 'Toyota',
    model: 'Camry',
    year: 2018,
    start: function() {
        console.log(this.model + '\'s Engine started');
    },
    stop: function() {
        console.log(this.model + '\'s Engine stopped');
    },
    service: () => {
        console.log(this.model + '\'s Engine serviced');
    }
};

car.start();
car.stop();
car.service();