console.log('Hi All !!');

const uName = 'John';
let uAge = 25;
console.log('User Name: ' + uName);
console.log('User Age: ' + uAge);

//uName = true;
uAge = 'Max';

console.log('User Name: ' + uName);
console.log('User Age: ' + uAge);

const car = {
    make: 'Toyota',
    model: 'Camry',
    year: 2018
};

car.make = 'Honda';

car = null;

console.log('Car Make: ' + car.make);

// let and const